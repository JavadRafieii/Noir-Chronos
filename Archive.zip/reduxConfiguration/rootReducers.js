import cart from "./basketSlice";
import wishlist from "./wishlistSlice"

const rootReducer = {
    cart,
    wishlist,
};

export default rootReducer;